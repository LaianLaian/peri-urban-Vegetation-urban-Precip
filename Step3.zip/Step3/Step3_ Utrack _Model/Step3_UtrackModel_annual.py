# This script processes annual moisture source contributions for multiple cities using UTrack monthly climatology data.
# For each city, it reads 12 monthly NetCDF files of moisture inflow and calculates the annual average precipitation source contribution.
# The analysis applies a local 11×11 grid mask centered on each city to focus on local source regions.

import numpy as np
import pandas as pd
from netCDF4 import Dataset
import os
import gc

def create_mask(lon_idx, lat_idx, shape, buffer_size=5):
    """
    Create a boolean mask that preserves a square region of (2*buffer_size+1)^2 grid cells
    around a target location. This ensures a local 11x11 window is retained.

    Parameters:
        lon_idx (int): Longitude index of the target grid cell.
        lat_idx (int): Latitude index of the target grid cell.
        shape (tuple): Grid shape (n_lon, n_lat).
        buffer_size (int): Size of the buffer window (default=5).

    Returns:
        mask (np.ndarray): Boolean array of same shape, True within buffer window.
    """
    mask = np.zeros(shape, dtype=bool)

    # Handle longitude wrapping
    for i in range(-5, 6):  # -5 to 5 (11 grid cells)
        for j in range(-5, 6):
            current_lon = (lon_idx + i) % shape[0]
            current_lat = lat_idx + j
            if 0 <= current_lat < shape[1]:
                mask[current_lon, current_lat] = True

    return mask

def process_city_data_annual():
    # Read city coordinate data
    print("Reading city coordinates...")
    df = pd.read_excel('city_latlon.xlsx')
    print("City data columns:", list(df.columns))
    print()

    n_cities = len(df)
    batch_size = 50  # Number of cities per batch

    # Create output NetCDF file
    with Dataset('city_utrack_results_annual.nc', 'w') as nc:
        # Define dimensions
        nc.createDimension('city', n_cities)
        nc.createDimension('lon', 720)
        nc.createDimension('lat', 360)

        # Define variables
        city_id = nc.createVariable('city_id', 'i4', ('city',))
        city_lat = nc.createVariable('city_lat', 'f4', ('city',))
        city_lon = nc.createVariable('city_lon', 'f4', ('city',))
        lon = nc.createVariable('lon', 'f4', ('lon',))
        lat = nc.createVariable('lat', 'f4', ('lat',))
        data = nc.createVariable('annual_precipitation_source', 'f4', ('lon', 'lat', 'city'),
                                 chunksizes=(720, 360, 1), fill_value=np.nan)

        # Add variable metadata
        city_id.long_name = 'City ID'
        city_lat.long_name = 'City Latitude'
        city_lat.units = 'degrees_north'
        city_lon.long_name = 'City Longitude'
        city_lon.units = 'degrees_east'
        lon.long_name = 'Longitude'
        lon.units = 'degrees_east'
        lat.long_name = 'Latitude'
        lat.units = 'degrees_north'
        data.long_name = 'Annual Average Precipitation Source Contribution'
        data.units = 'percent'

        # Write metadata values
        city_id[:] = df['ID'].values
        city_lat[:] = df['lat'].values
        city_lon[:] = df['lon'].values
        lon[:] = np.arange(0, 360, 0.5)
        lat[:] = np.arange(90, -90, -0.5)

        # Process cities in batches
        for batch_start in range(0, n_cities, batch_size):
            batch_end = min(batch_start + batch_size, n_cities)
            print(f"\nProcessing cities {batch_start + 1} to {batch_end}...")

            # Initialize batch data array
            batch_data_annual = np.full((720, 360, batch_end - batch_start), np.nan, dtype=np.float32)

            for city_idx in range(batch_start, batch_end):
                rel_idx = city_idx - batch_start
                print(f"\nProcessing city {city_idx + 1}/{n_cities}...")
                city_id_val = df['ID'].iloc[city_idx]
                city_lat_val = df['lat'].iloc[city_idx]
                city_lon_val = df['lon'].iloc[city_idx]
                print(f"City ID: {city_id_val}")

                # Convert longitude to 0–360 if needed
                if city_lon_val < 0:
                    city_lon_val += 360

                # Convert lat/lon to grid index
                target_lat_idx = int(round(180 - city_lat_val / 0.5 + 1)) - 1
                target_lon_idx = int(round(city_lon_val / 0.5 + 1)) - 1
                target_lat_idx = max(0, min(359, target_lat_idx))
                target_lon_idx = max(0, min(719, target_lon_idx))

                # Create local mask
                mask = create_mask(target_lon_idx, target_lat_idx, (720, 360))

                # Initialize monthly contribution arrays
                monthly_contributions = np.zeros((720, 360, 12), dtype=np.float32)
                valid_months = np.zeros((720, 360), dtype=np.int32)

                # Loop over 12 months
                for month in range(1, 13):
                    print(f"Processing month {month}...")
                    filename = f'utrack_climatology_0.5_{month:02d}.nc'

                    try:
                        print(f"Reading file: {filename}...")
                        with Dataset(filename, 'r') as nc_in:
                            MOI = nc_in.variables['moisture_flow'][:, :, target_lat_idx, target_lon_idx]
                            MOI = np.array(MOI, dtype=np.float32)

                            # Compute source contribution via exponential decay
                            source_contribution = np.exp(MOI * -0.1)
                            source_contribution = np.nan_to_num(source_contribution, 0)

                            if np.all(source_contribution == 0):
                                print(f"Warning: all contributions are zero for city {city_id_val} in month {month}")
                                continue

                            # Normalize to percentage
                            total = np.sum(source_contribution)
                            if total > 0:
                                source_contribution = source_contribution / total * 100

                            # Transpose and store
                            source_contribution = source_contribution.T
                            monthly_contributions[:, :, month - 1] = source_contribution
                            valid_months[source_contribution > 0] += 1

                    except Exception as e:
                        print(f"Error processing file {filename}: {str(e)}")
                        continue

                # Compute annual mean (only valid months)
                annual_contribution = np.sum(monthly_contributions, axis=2) / np.maximum(valid_months, 1)

                # Apply spatial mask
                annual_contribution = np.where(mask, annual_contribution, np.nan)

                # Store in batch array
                batch_data_annual[:, :, rel_idx] = annual_contribution

                # Print summary statistics
                valid_data = annual_contribution[~np.isnan(annual_contribution)]
                if len(valid_data) > 0:
                    print(f"\nAnnual stats – Range: [{np.min(valid_data):.2f}, {np.max(valid_data):.2f}], "
                          f"Mean: {np.mean(valid_data):.2f}, "
                          f"Sum: {np.sum(valid_data):.2f}%, "
                          f"Valid grid cells: {len(valid_data)}")

                gc.collect()

            # Save current batch to NetCDF
            print(f"\nSaving annual results for batch {batch_start + 1} to {batch_end}...")
            data[:, :, batch_start:batch_end] = batch_data_annual

            del batch_data_annual
            gc.collect()

    print("\nProcessing complete!")

if __name__ == '__main__':
    process_city_data_annual()
