# In order to conduct the analysis of ΔLAI-wind direction coherence,
# this script checks the spatial coherence between peri-urban ΔLAI trends
# and dominant wind directions.
# For each city:
# - Identify sector (East, South, West, North) with strongest ΔLAI
# - Calculate average wind direction within city boundary
# - Evaluate whether vegetation growth sector aligns with wind direction

import geopandas as gpd
import rasterio
import rasterio.mask
import numpy as np
import pandas as pd
from shapely.geometry import Point, Polygon, MultiPolygon
import warnings
warnings.filterwarnings('ignore')

# Compute azimuth angle from rural pixel to city center
def calculate_azimuth(lon1, lat1, lon2, lat2):
    """Calculate azimuth from point 1 to point 2 (degrees, 0 is north, clockwise)"""
    dlon = np.radians(lon2 - lon1)
    lat1 = np.radians(lat1)
    lat2 = np.radians(lat2)
    x = np.sin(dlon) * np.cos(lat2)
    y = np.cos(lat1)*np.sin(lat2) - np.sin(lat1)*np.cos(lat2)*np.cos(dlon)
    azimuth = np.degrees(np.arctan2(x, y))
    return (azimuth + 360) % 360

# Adjust geometries from [-180, 180] to [0, 360]
def adjust_longitude(geom):
    """Adjust geometry longitude from [-180,180] to [0,360] range"""
    if geom.is_empty:
        return geom
    def adjust_coords(coords):
        return [(x + 360 if x < 0 else x, y) for x, y in coords]
    if geom.geom_type == 'Point':
        x, y = geom.x, geom.y
        return Point(x + 360 if x < 0 else x, y)
    elif geom.geom_type == 'Polygon':
        exterior = adjust_coords(geom.exterior.coords)
        interiors = [adjust_coords(interior.coords) for interior in geom.interiors]
        return Polygon(exterior, holes=interiors)
    elif geom.geom_type == 'MultiPolygon':
        return MultiPolygon([adjust_longitude(poly) for poly in geom.geoms])
    return geom

# Assign direction label based on azimuth
def get_sector(angle):
    """Return sector name for a given azimuth angle (degrees)"""
    if 45 <= angle < 135:
        return 'East'
    elif 135 <= angle < 225:
        return 'South'
    elif 225 <= angle < 315:
        return 'West'
    else:
        return 'North'  # 315–360 or 0–45

# Main workflow
def main():
    try:
        # Load peri-urban ring shapefile
        gdf = gpd.read_file('2018vi.shp')
        print(f"Vector data CRS: {gdf.crs}")
        print(f"Vector data bounds: {gdf.total_bounds}")

        # Load urban core shapefile
        city_gdf = gpd.read_file('F:/0023/figure4/2018ur.shp')
        print(f"City data CRS: {city_gdf.crs}")

        # Reproject city CRS to match rural layer if needed
        if city_gdf.crs != gdf.crs:
            print(f"Converting city data CRS from {city_gdf.crs} to {gdf.crs}")
            city_gdf = city_gdf.to_crs(gdf.crs)

        # Load LAI trend and wind direction raster
        with rasterio.open('laiTREND.tif') as lai_src, rasterio.open('F:/0023/figure4/era5-mon-wind-0021/wind_angle005.tif') as wind_src:
            print(f"Raster data CRS: {lai_src.crs}")
            print(f"Raster data bounds: {lai_src.bounds}")
            print("\nResolution information:")
            print(f"LAI data resolution: {lai_src.res}")
            print(f"Wind data resolution: {wind_src.res}")
            print(f"LAI data shape: {lai_src.shape}")
            print(f"Wind data shape: {wind_src.shape}")

            # Reproject shapefiles to raster CRS if necessary
            if gdf.crs != lai_src.crs:
                print(f"Converting rural data CRS from {gdf.crs} to {lai_src.crs}")
                gdf = gdf.to_crs(lai_src.crs)
                city_gdf = city_gdf.to_crs(lai_src.crs)
                print(f"Rural data bounds after CRS conversion: {gdf.total_bounds}")

            # Adjust longitudes for raster alignment
            gdf['geometry'] = gdf['geometry'].apply(adjust_longitude)
            city_gdf['geometry'] = city_gdf['geometry'].apply(adjust_longitude)
            print(f"Rural data bounds after longitude adjustment: {gdf.total_bounds}")
            print(f"City data bounds after longitude adjustment: {city_gdf.total_bounds}")

            # Remove invalid geometries
            gdf['geometry'] = gdf['geometry'].buffer(0)
            city_gdf['geometry'] = city_gdf['geometry'].buffer(0)
            gdf = gdf[gdf.is_valid]
            city_gdf = city_gdf[city_gdf.is_valid]

            # Check if raster bounds cover the geometries
            if not (gdf.total_bounds[0] <= lai_src.bounds[2] and 
                    gdf.total_bounds[2] >= lai_src.bounds[0] and 
                    gdf.total_bounds[1] <= lai_src.bounds[3] and 
                    gdf.total_bounds[3] >= lai_src.bounds[1]):
                print("Warning: Vector and raster data ranges do not overlap!")
                return

            results = []
            for idx, row in gdf.iterrows():
                try:
                    geom = row.geometry
                    if geom.is_empty:
                        print(f"City {idx}: Empty geometry, skipping")
                        continue

                    # Find city polygons within rural ring
                    city_in_rural = city_gdf[city_gdf.intersects(geom)]
                    if city_in_rural.empty:
                        print(f"City {idx}: No city polygon found inside rural ring, skipping")
                        continue

                    # Merge multiple city polygons
                    city_union = city_in_rural.unary_union
                    city_centroid = city_union.centroid
                    center_x, center_y = city_centroid.x, city_centroid.y

                    bounds = geom.bounds
                    with rasterio.open('laiTREND.tif') as lai_src, rasterio.open('F:/0023/figure4/era5-mon-wind-0021/wind_angle005.tif') as wind_src:
                        if not (bounds[0] <= lai_src.bounds[2] and 
                                bounds[2] >= lai_src.bounds[0] and 
                                bounds[1] <= lai_src.bounds[3] and 
                                bounds[3] >= lai_src.bounds[1]):
                            print(f"City {idx}: Out of raster bounds, skipping")
                            continue

                        # Clip LAI and wind data to rural geometry
                        out_image, out_transform = rasterio.mask.mask(lai_src, [geom], crop=True, filled=False)
                        out_wind, _ = rasterio.mask.mask(wind_src, [geom], crop=True, filled=False)
                        lai_clip = np.array(out_image[0], copy=True)
                        wind_clip = np.array(out_wind[0], copy=True)

                        # Compute direction from rural grid to city center
                        abs_lai = np.abs(lai_clip)
                        if np.all(np.isnan(abs_lai)):
                            print(f"City {idx}: All LAI values are invalid, skipping")
                            continue
                        rows, cols = lai_clip.shape
                        angles = np.full_like(lai_clip, np.nan, dtype=float)
                        for r in range(rows):
                            for c in range(cols):
                                if np.isnan(lai_clip[r, c]):
                                    continue
                                x, y = rasterio.transform.xy(out_transform, r, c)
                                angles[r, c] = calculate_azimuth(x, y, center_x, center_y)

                        # Assign LAI values to directional sectors
                        sector_names = ['East', 'South', 'West', 'North']
                        sector_masks = [
                            (angles >= 45) & (angles < 135),   # East
                            (angles >= 135) & (angles < 225),  # South
                            (angles >= 225) & (angles < 315),  # West
                            ((angles >= 315) & (angles < 360)) | ((angles >= 0) & (angles < 45))  # North
                        ]
                        sector_lai = [np.nanmean(lai_clip[mask]) if np.any(mask) else np.nan for mask in sector_masks]
                        max_sector_idx = int(np.nanargmax(sector_lai))
                        max_sector = sector_names[max_sector_idx]

                        # Clip wind angle data within city boundary
                        try:
                            city_wind_clip, _ = rasterio.mask.mask(wind_src, [city_union], crop=True, filled=False)
                            city_wind_clip = np.array(city_wind_clip[0], copy=True)
                            valid_city_wind = city_wind_clip[~np.isnan(city_wind_clip)]
                            if len(valid_city_wind) == 0:
                                city_wind_sector = None
                            else:
                                radians = np.deg2rad(valid_city_wind)
                                mean_u = np.nanmean(np.cos(radians))
                                mean_v = np.nanmean(np.sin(radians))
                                mean_angle = (np.rad2deg(np.arctan2(mean_v, mean_u))) % 360
                                city_wind_sector = get_sector(mean_angle)
                        except Exception as e:
                            print(f"City {idx}: Error masking city wind: {str(e)}")
                            city_wind_sector = None

                        # Determine if dominant LAI and wind directions match
                        is_consistent = (max_sector == city_wind_sector)
                        results.append({
                            'city_id': row['ORIG_FID'] if 'ORIG_FID' in row else idx,
                            'max_lai_sector': max_sector,
                            'city_wind_sector': city_wind_sector,
                            'is_consistent': is_consistent
                        })
                except Exception as e:
                    print(f"Error processing city {idx}: {str(e)}")
                    continue

            # Save result to CSV
            if results:
                df = pd.DataFrame(results)
                df.to_csv('city_lai_wind_sector_consistency.csv', index=False)
                print(f"Analysis complete. Results saved to city_lai_wind_sector_consistency.csv. Processed {len(results)} cities.")
            else:
                print("No valid results found")
    except Exception as e:
        print(f"Program execution error: {str(e)}")

if __name__ == "__main__":
    main()
