% This script splits the RPR/RPR-T indicator by urban classification 
% and conducts statistical tests for Fig 4 panels.
% Output is written into one Excel file.

%Note:Based on a series of data, we conducted urban classification
%by running Python codes (compute_Vegetation structure continuity.py and compute_ΔLAI-wind direction coherence.py) 
%and using the Zonal Statistics as Table tool in ArcGIS
%the classification results are recorded in Step4_Groups.xlsx.
%% Groups for RPR
clear; clc;
% PARAMETERS
% input_file  = 'G:\Code\Step4\Step4_Groups_RPR_RPR-T.xlsx';
input_file  = 'C:\Users\evenp\Downloads\Step4\Step4\Step4_Groups_RPR_RPR-T.xlsx';
sheet_name  = 'Groups_RPR';
% output_file = 'G:\Code\RPR_RPR-T_group.xlsx';  
output_file = 'C:\Users\evenp\Downloads\Step4\Step4\RPR_group.xlsx';  
% Column index of RPR
value_col      = 2;
% Column index of Areal RPR
Areal_value_col      = 3;
% Column index of city classification columns
class_cols  = 4:13;

% Significance level for tests
alpha       = 0.05;

% LOAD INPUT DATA
[~, ~, raw] = xlsread(input_file, sheet_name);
headers = raw(1, :);
data_cells = raw(2:end, :);

% PART I: Split RPR by each classification and save sheets
for col = class_cols
    class_name = headers{col};
    class_vals = data_cells(:, col);

    if strcmp(class_name, 'Transport distance proxy')
        data_col = Areal_value_col;% For criterion of "Transport distance proxy", use Areal_RPR for analysis
    else
        data_col = value_col;% For other criteria, use RPR for analysis
    end
    values = cell2mat(data_cells(:, data_col));

    % Identify unique, nonempty classes
    groups = unique(class_vals);
    groups = groups(groups ~= "");

    % Prepare split matrix: each column = one class
    splits = cell(length(groups), 1);
    maxlen = 0;
    for i = 1:numel(groups)
        mask = strcmp(class_vals, groups(i));
        vals = values(mask);
        splits{i} = vals;
        maxlen = max(maxlen, numel(vals));
    end

    M = NaN(maxlen, numel(groups));
    for i = 1:numel(groups)
        M(1:numel(splits{i}), i) = splits{i};
    end

    % Write to sheet named after the classification
    writecell(cellstr(groups)', output_file, 'Sheet', [class_name], 'Range', 'A1');
    writematrix(M, output_file, 'Sheet', [class_name], 'Range', 'A2');
    fprintf('Written sheet: %s → saved as: %s\n', class_name, [class_name]);
end

% PART II: Pairwise tests within each classification (median only)
results = {};
header = { ...
    'Criteria','Category1','Category2','N1','N2', ...
    'Median1','Median2','zStat','p-value(Median)','Sig.(Median)' ...
    };

for col = class_cols
    class_name = headers{col};
    % Read the split sheet back
    [~, ~, raw] = xlsread(output_file, [class_name]);
    groups = raw(1, :);
    dataM  = cell2mat(raw(2:end, :));

    % Determine which columns actually have data
    valid_cols = find(~all(isnan(dataM),1));
    if numel(valid_cols) < 2
        continue;
    end

    combos = nchoosek(valid_cols, 2);
    for k = 1:size(combos,1)
        group1 = dataM(:, combos(k,1));
        group2 = dataM(:, combos(k,2));
        group1 = rmmissing(group1);
        group2 = rmmissing(group2);

        %Wilcoxon rank-sum test for median difference
        median1 = median(group1);
        median2 = median(group2);
        [pMed, ~, statsMed] = ranksum(group1, group2, 'Alpha', alpha);

        if isfield(statsMed, 'zval')
            z_stat = statsMed.zval;
        elseif isfield(statsMed, 'z')
            z_stat = statsMed.z;
        else
            z_stat = NaN;
        end

        results(end+1,:) = { ...
            class_name, groups{combos(k,1)}, groups{combos(k,2)}, ...
            numel(group1), numel(group2), ...
            median1, median2, z_stat, pMed, pMed<alpha ...
            };
    end
end

% WRITE RESULTS
T = cell2table(results, 'VariableNames', header);
writetable(T, output_file, 'Sheet', 'RPR_Summary', 'WriteMode','overwritesheet');

disp('RPR group tests complete');


%% Groups for RPR-T
clear;
% PARAMETERS
% input_file  = 'G:\Code\Step4\Step4_Groups_RPR_RPR-T.xlsx';
input_file  = 'C:\Users\evenp\Downloads\Step4\Step4\Step4_Groups_RPR_RPR-T.xlsx';
sheet_name  = 'Groups_RPR-T';
output_file = 'C:\Users\evenp\Downloads\Step4\Step4\RPR-T_group.xlsx';  
alpha = 0.05;
% Column index of RPR-T
value_col      = 2;
% Column index of Areal RPR-T
Areal_value_col      = 3;
% Column index of city classification columns
class_cols  = 4:13;

% LOAD INPUT DATA
[~, ~, raw] = xlsread(input_file, sheet_name);
headers = raw(1, :);
data_cells = raw(2:end, :);

% PART I: Split RPR-T by each classification and save sheets
for col = class_cols
    class_name = headers{col};
    class_vals = data_cells(:, col);

    if strcmp(class_name, 'Transport distance proxy')
        data_col = Areal_value_col;% For criterion of "Transport distance proxy", use Areal_RPR for analysis
    else
        data_col = value_col;% For other criteria, use RPR-T for analysis
    end
    values = cell2mat(data_cells(:, data_col));

    % Identify unique, nonempty classes
    groups = unique(class_vals);
    groups = groups(groups ~= "");

    % Prepare split matrix: each column = one class
    splits = cell(length(groups), 1);
    maxlen = 0;
    for i = 1:numel(groups)
        mask = strcmp(class_vals, groups(i));
        vals = values(mask);
        splits{i} = vals;
        maxlen = max(maxlen, numel(vals));
    end

    M = NaN(maxlen, numel(groups));
    for i = 1:numel(groups)
        M(1:numel(splits{i}), i) = splits{i};
    end

    % Write to sheet named after the classification
    writecell(cellstr(groups)', output_file, 'Sheet', [class_name], 'Range', 'A1');
    writematrix(M, output_file, 'Sheet', [class_name], 'Range', 'A2');
    fprintf('Written sheet: %s → saved as: %s\n', class_name, [class_name]);
end

% PART II: Pairwise tests within each classification (median only)
results = {};
header = { ...
    'Criteria','Category1','Category2','N1','N2', ...
    'Median1','Median2','zStat','p-value(Median)','Sig.(Median)' ...
    };

for col = class_cols
    class_name = headers{col};
    % Read the split sheet back
    [~, ~, raw] = xlsread(output_file, [class_name]);
    groups = raw(1, :);
    dataM  = cell2mat(raw(2:end, :));

    % Determine which columns actually have data
    valid_cols = find(~all(isnan(dataM),1));
    if numel(valid_cols) < 2
        continue;
    end

    combos = nchoosek(valid_cols, 2);
    for k = 1:size(combos,1)
        group1 = dataM(:, combos(k,1));
        group2 = dataM(:, combos(k,2));
        group1 = rmmissing(group1);
        group2 = rmmissing(group2);

        %Wilcoxon rank-sum test for median difference
        median1 = median(group1);
        median2 = median(group2);
        [pMed, ~, statsMed] = ranksum(group1, group2, 'Alpha', alpha);

        if isfield(statsMed, 'zval')
            z_stat = statsMed.zval;
        elseif isfield(statsMed, 'z')
            z_stat = statsMed.z;
        else
            z_stat = NaN;
        end

        results(end+1,:) = { ...
            class_name, groups{combos(k,1)}, groups{combos(k,2)}, ...
            numel(group1), numel(group2), ...
            median1, median2, z_stat, pMed, pMed<alpha ...
            };
    end
end

% WRITE RESULTS
T = cell2table(results, 'VariableNames', header);
writetable(T, output_file, 'Sheet', 'RPR-T_Summary', 'WriteMode','overwritesheet');

disp('RPR-T group tests complete');
