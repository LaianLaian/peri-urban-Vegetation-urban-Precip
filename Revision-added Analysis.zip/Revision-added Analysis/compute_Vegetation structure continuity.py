# In order to conduct the analysis of Vegetation structure continuity,
# this script computes the vegetation connectivity index (CI)
# for peri-urban regions based on LAI spatial patterns.

import os
import numpy as np
import rasterio
from skimage import measure
import pandas as pd

# ===============================================================
# 1. Define input and output paths
# ===============================================================
# Directory containing individual city LAI raster files (GeoTIFFs)
city_tif_dir = r"G:\0023\figure4\LAI500m_city"

# Output CSV file where results will be stored
out_csv = r"G:\0023\figure4\LAI500m_city_connectivity.csv"

# ===============================================================
# 2. Define analytical parameters
# ===============================================================
lai_threshold = 2.0   # Threshold: pixels with LAI > 2 are considered vegetated
connectivity = 2      # Connectivity type: 1 = 4-neighbor, 2 = 8-neighbor connectivity

results = []  # Initialize list to store per-city metrics

# ===============================================================
# 3. Loop through all city raster files
# ===============================================================
for file in os.listdir(city_tif_dir):
    # Process only GeoTIFF files
    if not file.endswith(".tif"):
        continue

    # Extract city ID from filename
    city_id = os.path.splitext(file)[0].replace("city_", "")
    file_path = os.path.join(city_tif_dir, file)

    # ---------------------------------------------------------------
    # 3.1 Read LAI raster for this city
    # ---------------------------------------------------------------
    with rasterio.open(file_path) as src:
        data = src.read(1).astype(float)  # Read first raster band

        # Remove invalid (negative) values
        data[data < 0] = np.nan

        # Binarize: 1 = vegetated (LAI > threshold), 0 = non-vegetated
        binary = np.where(data > lai_threshold, 1, 0)

        # Skip if raster contains only missing values
        if np.all(np.isnan(data)):
            print(f"⚠ City {city_id}: No valid data found, skipped.")
            continue

        # ---------------------------------------------------------------
        # 3.2 Connected-component analysis for vegetated patches
        # ---------------------------------------------------------------
        # Label contiguous vegetated regions
        labeled = measure.label(binary, connectivity=connectivity)

        # Extract geometric properties of connected regions
        props = measure.regionprops(labeled)

        # Compute area of the largest vegetated patch (in pixels)
        if len(props) == 0:
            max_patch_area = 0
        else:
            areas = [p.area for p in props]
            max_patch_area = np.max(areas)

        # Total number of vegetated pixels
        total_area = np.sum(binary == 1)

        # ---------------------------------------------------------------
        # 3.3 Compute connectivity index
        # ---------------------------------------------------------------
        # Connectivity = largest patch / total vegetated area
        if total_area > 0:
            connectivity_index = max_patch_area / total_area
        else:
            connectivity_index = 0

        # Append results
        results.append({
            "city_id": city_id,
            "total_veg_pixels": int(total_area),
            "largest_patch_pixels": int(max_patch_area),
            "connectivity_index": connectivity_index
        })

        print(f" City {city_id}: Connectivity index = {connectivity_index:.3f}")

# ===============================================================
# 4. Save per-city connectivity statistics
# ===============================================================
df = pd.DataFrame(results)
df.to_csv(out_csv, index=False, encoding="utf-8-sig")

print(f"\n Connectivity analysis completed successfully.")
print(f"Results saved to: {out_csv}")