#To examine the temporal response between vegetation change and precipitation change,
#this script quantifies the temporal dynamics between peri-urban vegetation (LAI)
#and urban precipitation anomalies (DeltaPur) by performing a lag correlation analysis
#(lag month = 0, 1, 2, 3) based on monthly data across 1,029 cities.

import numpy as np
from scipy.stats import spearmanr

# ============================================================
# 1. Input and output configuration
# ============================================================
input_csv = r"G:\0023\monthly\LAI_DeltaPur_merged_long_table.csv"
output_xlsx = r"G:\0023\monthly\LAI_DeltaPur_lag_corr_signed.xlsx"

# ============================================================
# 2. Data loading and structure
# ============================================================
# Read the long-format table containing monthly LAI and precipitation difference (DeltaPur)
df = pd.read_csv(input_csv)
print(f"Input data loaded: {df['CityID'].nunique()} cities, {len(df)} monthly records.")

# Initialize containers for storing results
corr_results = {}   # Spearman correlation coefficients
pval_results = {}   # p-values for statistical significance
lag_max = {}        # Best lag (L0–L3) per city

# ============================================================
# 3. Lag correlation computation for each city
# ============================================================
for city in df["CityID"].unique():
    # Extract monthly data for the current city
    sub = df[df["CityID"] == city].sort_values(by=["Year", "Month"])
    lai = sub["LAI"].values
    pur = sub["DeltaPur"].values

    # Prepare containers for this city's results
    corr_results[city] = {}
    pval_results[city] = {}

    max_corr = -np.inf
    max_lag = None

    # --------------------------------------------------------
    # Compute lagged correlation: LAI(t−lag) vs. DeltaPur(t)
    # --------------------------------------------------------
    for lag in range(0, 4):  # Lag 0 to 3 months
        if lag == 0:
            lai_lag, pur_lag = lai, pur
        else:
            lai_lag, pur_lag = lai[:-lag], pur[lag:]

        # Exclude NaN values before correlation
        mask = ~np.isnan(lai_lag) & ~np.isnan(pur_lag)

        if mask.sum() > 1:
            corr, pval = spearmanr(lai_lag[mask], pur_lag[mask])
        else:
            corr, pval = np.nan, np.nan

        corr_results[city][lag] = corr
        pval_results[city][lag] = pval

        # Track the lag with the maximum (most positive) correlation
        if not np.isnan(corr) and corr > max_corr:
            max_corr = corr
            max_lag = lag  # Save best lag index as integer

    lag_max[city] = max_lag

# ============================================================
# 4. Convert dictionaries to structured DataFrames
# ============================================================
df_corr = pd.DataFrame.from_dict(corr_results, orient="index")
df_pval = pd.DataFrame.from_dict(pval_results, orient="index")
df_lagmax = pd.Series(lag_max, name="BestLag")

# ============================================================
# 5. Summary statistics: distribution of best-performing lags
# ============================================================
lag_counts = df_lagmax.value_counts().sort_index()
print("Distribution of best-performing lag (months):")
print(lag_counts)

# ============================================================
# 6. Export results to Excel
# ============================================================
with pd.ExcelWriter(output_xlsx) as writer:
    df_corr.to_excel(writer, sheet_name="SpearmanCorr")
    df_pval.to_excel(writer, sheet_name="Pvalue")
    df_lagmax.to_excel(writer, sheet_name="BestLag")

print(f"Lag analysis completed successfully. Results saved to: {output_xlsx}")
