#  To assess whether past values of LAIperi (Pur) significantly improve the prediction of Pur (LAIperi)evaluate the directional information flow between 
#  this script performs a panel Granger causality analysis for 1,029 cities during 2000–2021.
#  Peri-urban vegetation: LAIperi
#  Urban precipitation: Pur
#
#  For each city:
#   (1) Read annual LAI and P time series for each city (2000–2021);
#   (2) Perform Granger causality tests in both directions (LAI→P and P→LAI);
#   (3) Repeat tests three times per city for stability and average results;
#   (4) Determine the dominant causal direction for each city;
#   (5) Perform a Wilcoxon signed-rank test to evaluate overall significance;
#   (6) Save the F-statistics, p-values, and causal direction to Excel output.


import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.tsa.stattools import grangercausalitytests
from statsmodels.stats.multitest import multipletests


def panel_granger_test(x, y, maxlag=1):
    """
    Perform a single-city Granger causality test.

    Parameters:
        x, y (array-like): Time series of variables X and Y.
        maxlag (int): Maximum number of lag periods.

    Returns:
        f_stat (float): F-statistic value.
        p_value (float): Associated p-value for the test.
    """
    # ----------------------------- Data normalization --------------------------
    # Standardize both time series (mean=0, std=1) to avoid scale bias.
    x = (x - np.mean(x)) / np.std(x)
    y = (y - np.mean(y)) / np.std(y)

    # Combine the series into a DataFrame for the test.
    data = pd.DataFrame({'x': x, 'y': y})

    # ------------------------ Perform Granger causality test -------------------
    results = grangercausalitytests(data, maxlag=maxlag, verbose=False)

    # Extract the F-statistic and p-value for the specified lag.
    f_stat = results[maxlag][0]['ssr_ftest'][0]
    p_value = results[maxlag][0]['ssr_ftest'][1]

    return f_stat, p_value


def analyze_panel_causality():
    """
    Conduct the full panel Granger causality analysis across all cities.
    This includes reading data, performing causality tests, summarizing
    results, and conducting overall significance testing.
    """
    print("Step 1: Reading input data files (LAI and precipitation)...")

    # ----------------------------- Data Loading -------------------------------
    try:
        # Read LAI and precipitation time series (each row = one city)
        lai_data = pd.read_excel('LAIvi_yr.xlsx', sheet_name='Sheet1', header=None)
        pur_data = pd.read_excel('Pur_yr.xlsx', sheet_name='Sheet1', header=None)
    except Exception as e:
        print(f"Error occurred while reading input files: {str(e)}")
        return

    # Exclude the last column (multi-year mean)
    lai_ts = lai_data.iloc[:, :-1]
    pur_ts = pur_data.iloc[:, :-1]

    total_cities = len(lai_ts)
    print(f"Successfully loaded data for {total_cities} cities.")

    # Initialize list to store per-city causality test results.
    results = []

    # ----------------------------- Main Analysis Loop -------------------------
    for city in range(total_cities):
        try:
            lai_series = lai_ts.iloc[city].values
            pur_series = pur_ts.iloc[city].values

            # Skip cities with invalid or constant data
            if np.isnan(lai_series).any() or np.isnan(pur_series).any():
                continue
            if np.all(lai_series == 0) or np.all(pur_series == 0):
                continue
            if np.all(lai_series == lai_series[0]) or np.all(pur_series == pur_series[0]):
                continue

            print(f"\nProcessing City {city + 1}/{total_cities}")
            print("=" * 60)

            # Initialize containers for repeated Granger test results
            f_lai_to_pur_list, f_pur_to_lai_list = [], []
            p_lai_to_pur_list, p_pur_to_lai_list = [], []

            # ------------------------ Repeated Testing (3 runs) -----------------
            for i in range(3):
                f_lai_to_pur, p_lai_to_pur = panel_granger_test(lai_series, pur_series)
                f_pur_to_lai, p_pur_to_lai = panel_granger_test(pur_series, lai_series)

                f_lai_to_pur_list.append(f_lai_to_pur)
                f_pur_to_lai_list.append(f_pur_to_lai)
                p_lai_to_pur_list.append(p_lai_to_pur)
                p_pur_to_lai_list.append(p_pur_to_lai)

                print(f"\nRun {i + 1}:")
                print(f"  LAI → P: F = {f_lai_to_pur:.4f}, p = {p_lai_to_pur:.4f}")
                print(f"  P → LAI: F = {f_pur_to_lai:.4f}, p = {p_pur_to_lai:.4f}")

            # --------------------------- Result Averaging -----------------------
            f_lai_to_pur = np.mean(f_lai_to_pur_list)
            f_pur_to_lai = np.mean(f_pur_to_lai_list)
            p_lai_to_pur = np.mean(p_lai_to_pur_list)
            p_pur_to_lai = np.mean(p_pur_to_lai_list)

            print("\nAveraged results across 3 runs:")
            print(f"  LAI → P: F = {f_lai_to_pur:.4f}, p = {p_lai_to_pur:.4f}")
            print(f"  P → LAI: F = {f_pur_to_lai:.4f}, p = {p_pur_to_lai:.4f}")
            print("=" * 60)

            # ------------------------ Determine Causal Direction ----------------
            if p_lai_to_pur < 0.05 and f_lai_to_pur > f_pur_to_lai:
                causal_direction = 'LAI→P'
            elif p_pur_to_lai < 0.05 and f_pur_to_lai > f_lai_to_pur:
                causal_direction = 'P→LAI'
            elif p_lai_to_pur < 0.05 and p_pur_to_lai < 0.05:
                causal_direction = 'Bidirectional'
            else:
                causal_direction = 'No significant relationship'

            # Store results for the current city
            results.append({
                'city': city + 1,
                'f_lai_to_pur': f_lai_to_pur,
                'f_pur_to_lai': f_pur_to_lai,
                'p_lai_to_pur': p_lai_to_pur,
                'p_pur_to_lai': p_pur_to_lai,
                'causal_direction': causal_direction
            })

        except Exception as e:
            print(f"Error processing City {city + 1}: {str(e)}")
            continue

    # ----------------------------- Convert to DataFrame -----------------------
    results_df = pd.DataFrame(results)

    print("\nStep 2: Summary of analysis results")
    print(f"  Total cities processed: {total_cities}")
    print(f"  Successfully analyzed: {len(results_df)}")

    # ------------------ Step 3: Global Significance Evaluation ----------------
    print("\nPerforming global significance test (Wilcoxon signed-rank test)...")
    statistic, p_value = stats.wilcoxon(results_df['f_lai_to_pur'], results_df['f_pur_to_lai'])
    print(f"  Statistic = {statistic:.4f}")
    print(f"  p-value   = {p_value:.4f}")

    if p_value < 0.05:
        print("  → Significant overall effect detected.")
        if np.mean(results_df['f_lai_to_pur']) > np.mean(results_df['f_pur_to_lai']):
            print("  → LAI exerts a stronger overall causal influence on precipitation.")
        else:
            print("  → Precipitation exerts a stronger overall causal influence on LAI.")
    else:
        print("  → No significant overall causality detected across cities.")

    # ------------------------ Step 4: Direction Summary -----------------------
    direction_counts = results_df['causal_direction'].value_counts()
    print("\nCausal direction summary across cities:")
    for direction, count in direction_counts.items():
        print(f"  {direction}: {count} cities ({count / len(results_df) * 100:.2f}%)")

    # ----------------------------- Step 5: Save Output ------------------------
    results_df.to_excel('panel_granger_results.xlsx', index=False)
    print("\nStep 5 completed: All detailed results have been saved to 'panel_granger_results.xlsx'.")
    print("Script execution finished successfully.")


# ------------------------------------------------------------------------------
# Main execution block
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    analyze_panel_causality()
