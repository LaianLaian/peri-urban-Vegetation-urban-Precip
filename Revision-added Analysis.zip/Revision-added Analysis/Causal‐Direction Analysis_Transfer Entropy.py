#  To evaluate the directional information flow between peri-urban vegetation (LAIperi) and urban precipitation (Pur),
#  this script quantifies causal interactions for 1,029cities during 2000–2021
#  using Transfer Entropy (TE) analysis with permutation-based significance tests.
#
#  For each city:
#    (1) Computes TE from LAIperi→Pur and Pur→LAIperi;
#    (2) Performs 3 independent permutation-based replicates for stability;
#    (3) Calculates empirical p-values based on 10,000 random shuffles;
#    (4) Identifies dominant causal direction (LAIperi→Pur, Pur→LAIperi, or Bidirectional);
#    (5) Conducts Wilcoxon signed-rank test across all cities for overall effect.


import numpy as np
import pandas as pd
from scipy import stats
from sklearn.preprocessing import KBinsDiscretizer


# ------------------------------------------------------------------------------
# Function: calculate_transfer_entropy
# ------------------------------------------------------------------------------
def calculate_transfer_entropy(x, y, lag=1, n_bins=8):
    """
    Compute the transfer entropy (TE_{x→y}) between two time series.

    Parameters:
        x (1D array): source time series
        y (1D array): target time series
        lag (int): lag length to consider (default=1)
        n_bins (int): number of bins for uniform discretization (default=8)

    Returns:
        float: estimated transfer entropy (in bits)
    """
    # ------------------------- Standardization -------------------------------
    # Standardize input series to zero mean and unit variance.
    x = (x - np.mean(x)) / np.std(x)
    y = (y - np.mean(y)) / np.std(y)

    # -------------------------- Discretization -------------------------------
    # Discretize both series into ordinal bins for information-theoretic analysis.
    disc = KBinsDiscretizer(n_bins=n_bins, encode='ordinal', strategy='uniform')
    x_disc = disc.fit_transform(x.reshape(-1, 1)).flatten()
    y_disc = disc.fit_transform(y.reshape(-1, 1)).flatten()

    # -------------------------- Lag Construction -----------------------------
    # Construct lagged versions of the time series.
    y_past = y_disc[:-lag]
    y_future = y_disc[lag:]
    x_past = x_disc[:-lag]
    N = len(y_past)

    # -------------------------- Probability Estimation -----------------------
    # Estimate joint frequency counts for TE computation.
    cnt_yf_yp = np.zeros((n_bins, n_bins))
    cnt_yf_yp_xp = np.zeros((n_bins, n_bins, n_bins))
    for i in range(N):
        cnt_yf_yp[y_future[i], y_past[i]] += 1
        cnt_yf_yp_xp[y_future[i], y_past[i], x_past[i]] += 1

    # Normalize to probabilities
    p_yf_yp = cnt_yf_yp / N
    p_yf_yp_x = cnt_yf_yp_xp / N
    p_yp = np.sum(p_yf_yp, axis=0)
    p_yp_x = np.sum(p_yf_yp_x, axis=0)

    # -------------------------- Transfer Entropy -----------------------------
    # Compute the TE_{x→y} using probability ratios.
    te = 0.0
    for i in range(n_bins):
        for j in range(n_bins):
            for k in range(n_bins):
                p_joint = p_yf_yp_x[i, j, k]
                if p_joint > 0 and p_yf_yp[i, j] > 0 and p_yp_x[j, k] > 0:
                    te += p_joint * np.log2(
                        (p_joint * p_yp[j]) / (p_yf_yp[i, j] * p_yp_x[j, k])
                    )
    # TE must be non-negative
    return max(0, te)


# ------------------------------------------------------------------------------
# Function: permutation_test
# ------------------------------------------------------------------------------
def permutation_test(x, y, n_permutations=10000, lag=1, n_bins=8):
    """
    Conduct a permutation-based significance test for transfer entropy.

    Parameters:
        x, y (1D arrays): time series (source and target)
        n_permutations (int): number of random shuffles (default=10,000)
        lag (int): lag for TE (default=1)
        n_bins (int): discretization bins (default=8)

    Returns:
        tuple: (observed TE, permutation-based p-value)
    """
    # Compute the original TE_{x→y}
    orig_te = calculate_transfer_entropy(x, y, lag, n_bins)

    # Generate null distribution by shuffling x
    perm_te = np.zeros(n_permutations)
    for i in range(n_permutations):
        x_shuf = np.random.permutation(x)
        perm_te[i] = calculate_transfer_entropy(x_shuf, y, lag, n_bins)

    # Empirical p-value: fraction of shuffled TE ≥ observed TE
    p_val = np.mean(perm_te >= orig_te)
    return orig_te, p_val


# ------------------------------------------------------------------------------
# Main Function: analyze_causality
# ------------------------------------------------------------------------------
def analyze_causality():
    """
    Main routine to compute TE-based causality between LAI and precipitation.

    Steps:
        1. Load annual LAI and precipitation data (2000–2021).
        2. Compute TE for both directions (LAI→P, P→LAI).
        3. Repeat each test 3 times per city for robustness.
        4. Determine dominant causal direction.
        5. Conduct Wilcoxon signed-rank test across all cities.
        6. Save detailed results to 'transfer_entropy_results.xlsx'.
    """
    print("Step 1: Loading input data (LAIvi_yr.xlsx, Pur_yr.xlsx)...")

    # -------------------------- Data Loading ---------------------------------
    # Read annual time series for 1,029 cities (excluding last multi-year mean column)
    lai_df = pd.read_excel('LAIvi_yr.xlsx', header=None).iloc[:, :-1]
    pur_df = pd.read_excel('Pur_yr.xlsx', header=None).iloc[:, :-1]
    n_cities = lai_df.shape[0]
    print(f"  Successfully loaded data for {n_cities} cities.")

    results = []

    # -------------------------- Per-City Analysis ----------------------------
    for city in range(n_cities):
        x = lai_df.iloc[city].to_numpy()
        y = pur_df.iloc[city].to_numpy()

        # Skip cities with invalid, zero, or constant series
        if np.isnan(x).any() or np.isnan(y).any():
            continue
        if np.all(x == 0) or np.all(y == 0):
            continue
        if np.all(x == x[0]) or np.all(y == y[0]):
            continue

        print(f"\nProcessing City {city + 1}/{n_cities} ...")

        # Determine the optimal number of bins using Sturges' rule (bounded 5–10)
        n_bins = max(5, min(10, int(np.log2(len(x)) + 1)))
        te_xy_list, te_yx_list = [], []
        p_xy_list, p_yx_list = [], []

        # ---------------------- Repeated Computation --------------------------
        # Run 3 independent permutation tests to stabilize TE estimates.
        for rep in range(3):
            te_xy, p_xy = permutation_test(x, y, n_bins=n_bins)
            te_yx, p_yx = permutation_test(y, x, n_bins=n_bins)
            te_xy_list.append(te_xy)
            te_yx_list.append(te_yx)
            p_xy_list.append(p_xy)
            p_yx_list.append(p_yx)
            print(f"  Rep {rep + 1}: TE(LAI→P)={te_xy:.4f}, TE(P→LAI)={te_yx:.4f}")

        # Average across three replicates
        te_xy = np.mean(te_xy_list)
        te_yx = np.mean(te_yx_list)
        p_xy = np.mean(p_xy_list)
        p_yx = np.mean(p_yx_list)

        # Determine dominant direction: requires ≥10% difference
        if te_xy > 1.1 * te_yx:
            direction = 'LAI→P'
        elif te_yx > 1.1 * te_xy:
            direction = 'P→LAI'
        else:
            direction = 'Bidirectional'

        results.append({
            'city': city + 1,
            'te_LAI→P': te_xy,
            'te_P→LAI': te_yx,
            'p_LAI→P': p_xy,
            'p_P→LAI': p_yx,
            'direction': direction
        })

    # -------------------------- Global Analysis ------------------------------
    df = pd.DataFrame(results)
    print("\nStep 2: Running Wilcoxon signed-rank test across all cities...")
    stat, p_w = stats.wilcoxon(df['te_LAI→P'], df['te_P→LAI'])
    print(f"  Wilcoxon test statistic = {stat:.4f}, p-value = {p_w:.4f}")

    if p_w < 0.05:
        if np.mean(df['te_LAI→P']) > np.mean(df['te_P→LAI']):
            print("  → LAI exerts a significantly stronger causal effect on P.")
        else:
            print("  → Precipitation exerts a significantly stronger causal effect on LAI.")
    else:
        print("  → No significant overall difference detected.")

    # -------------------------- Output Results -------------------------------
    df.to_excel('transfer_entropy_results.xlsx', index=False)
    print("\nStep 3 completed: Results saved to 'transfer_entropy_results.xlsx'.")
    print("Transfer entropy analysis completed successfully.")


# ------------------------------------------------------------------------------
# Script Execution Entry Point
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    analyze_causality()
