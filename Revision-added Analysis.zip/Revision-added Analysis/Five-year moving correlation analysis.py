# To evaluate the temporal robustness of the coupling
# between peri-urban vegetation and urban precipitation,
# this script perform a five-year moving correlation analysis for 1,029 cities

import pandas as pd
import numpy as np

# ============================================================
# 1. Input File Paths
# ============================================================
excel_file = r"G:\0023\Result_Value(1).xlsx"
output_csv = r"G:\0023\sliding_corr_results_with_labels.csv"

# ============================================================
# 2. Read Input Data (LAIperi and Pur)
# ============================================================
# Each sheet represents annual values of a variable for all cities
df_lai = pd.read_excel(excel_file, sheet_name="LAIperi", index_col=0)
df_pur = pd.read_excel(excel_file, sheet_name="Pur", index_col=0)

# Standardize column labels (years) to string format
df_lai.columns = df_lai.columns.astype(str).str.strip()
df_pur.columns = df_pur.columns.astype(str).str.strip()

# Retain only the overlapping years between datasets
common_years = df_lai.columns.intersection(df_pur.columns)
df_lai = df_lai[common_years]
df_pur = df_pur[common_years]

years = common_years.astype(int).sort_values()
window = 5  # five-year moving window length

results = []

print(f"Data successfully loaded. Common analysis period: {years.min()}–{years.max()}.")

# ============================================================
# 3. Moving-Window Correlation Calculation (per city)
# ============================================================
for city in df_lai.index:
    lai_series = df_lai.loc[city].astype(float)
    pur_series = df_pur.loc[city].astype(float)

    corrs = []
    # Slide a five-year window across the time series
    for i in range(len(years) - window + 1):
        y_win = years[i:i + window].astype(str)
        lai_win = lai_series[y_win]
        pur_win = pur_series[y_win]

        # Compute correlation only if no missing values exist
        if lai_win.isna().sum() == 0 and pur_win.isna().sum() == 0:
            corr = lai_win.corr(pur_win)
            corrs.append(corr)

    # ========================================================
    # 4. Robustness Statistics and Classification
    # ========================================================
    if len(corrs) > 0:
        mean_corr = np.mean(corrs)
        std_corr = np.std(corrs)
        # Robustness score: proportion of positive correlations
        robust_score = sum(c > 0 for c in corrs) / len(corrs)

        # Robustness classification criteria
        if mean_corr > 0.1 and robust_score >= 0.75:
            label = "Strongly robust"
        elif mean_corr > 0 and robust_score >= 0.5:
            label = "Moderately robust"
        elif mean_corr < -0.1 and robust_score >= 0.75:
            label = "Negative"
        else:
            label = "Weak/unstable"
    else:
        # Insufficient valid data for moving correlation
        mean_corr, std_corr, robust_score, label = np.nan, np.nan, np.nan, "Insufficient data"

    results.append({
        "City_ID": city,
        "mean_corr": mean_corr,
        "std_corr": std_corr,
        "robust_score": robust_score,
        "robust_label": label
    })

print("Moving correlation analysis completed for all cities.")

# ============================================================
# 5. Save Results
# ============================================================
df_result = pd.DataFrame(results)
df_result.to_csv(output_csv, index=False, encoding="utf-8-sig")
print(f" Results successfully saved to: {output_csv}")

# ============================================================
# 6. Summary Statistics by Robustness Category
# ============================================================
label_counts = df_result["robust_label"].value_counts()
print("\n Robustness classification summary:")
print(label_counts)

print("\nAnalysis completed successfully.")
