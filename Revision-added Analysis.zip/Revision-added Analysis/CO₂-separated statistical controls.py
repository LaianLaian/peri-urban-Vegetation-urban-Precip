# To isolate the vegetation–precipitation relationship from CO₂-induced climatic co-variations,
# this script performs CO₂-separated statistical controls by quantifying
# the independent effect of peri-urban vegetation (LAIperi) on urban precipitation (Pur)
# after accounting for the influence of atmospheric CO₂ concentration (2000–2021).
#The analysis combines:
#    1. Pearson correlation between LAIperi and Pur;
#    2. Partial correlation controlling for CO₂;
#    3. Multiple linear regression (non-standardized β coefficients);
#    4. Standardized β coefficients based on z-scored variables.

import pandas as pd
import numpy as np
from scipy.stats import pearsonr, zscore
from pingouin import partial_corr
import statsmodels.api as sm

# ============================================================
# 1. Read and preprocess CO₂ data
# ============================================================
co2_file = r"G:\0023\CO2\co2.csv"
df_co2 = pd.read_csv(co2_file)

# Retain only the first two columns: Year and CO₂ concentration
df_co2 = df_co2.iloc[:, :2]
df_co2.columns = ["Year", "CO2"]

# Convert year column to numeric in case of mixed types
df_co2["Year"] = pd.to_numeric(df_co2["Year"], errors="coerce")

# Select analysis period 2000–2021
df_co2 = df_co2[(df_co2["Year"] >= 2000) & (df_co2["Year"] <= 2021)].reset_index(drop=True)

years = df_co2["Year"].values
co2 = df_co2["CO2"].values

print(f"CO₂ data successfully loaded for {len(years)} years: {years[0]}–{years[-1]}")

# ============================================================
# 2. Read city-level LAIperi and Pur data
# ============================================================
result_file = r"G:\0023\CO2\Result_Value.xlsx"
df_pur = pd.read_excel(result_file, sheet_name="Pur")       # Urban precipitation
df_lai = pd.read_excel(result_file, sheet_name="LAIperi")   # Peri-urban vegetation

print(f"City-level datasets loaded: {df_pur.shape[0]} cities × {df_pur.shape[1] - 1} years")

# ============================================================
# 3. Statistical analysis for each city
# ============================================================
results = []

for i in range(df_pur.shape[0]):
    city_id = df_pur.iloc[i, 0]
    pur_vals = df_pur.iloc[i, 1:].values.astype(float)
    lai_vals = df_lai.iloc[i, 1:].values.astype(float)

    # Verify data length consistency
    if len(pur_vals) != len(co2):
        print(f"⚠️ Warning: City {city_id} length mismatch with CO₂ series — skipped.")
        continue

    # --------------------------------------------------------
    # (1) Pearson correlation between LAIperi and Pur
    # --------------------------------------------------------
    r_corr, p_corr = pearsonr(lai_vals, pur_vals)

    # --------------------------------------------------------
    # (2) Partial correlation controlling for CO₂
    # --------------------------------------------------------
    df_temp = pd.DataFrame({"P": pur_vals, "LAI": lai_vals, "CO2": co2})
    pcorr = partial_corr(data=df_temp, x="LAI", y="P", covar="CO2", method="pearson")
    r_pcorr = pcorr.iloc[0]["r"]
    p_pcorr = pcorr.iloc[0]["p-val"]

    # --------------------------------------------------------
    # (3) Multiple linear regression (non-standardized β)
    # Pur = β₀ + β₁·LAI + β₂·CO₂ + ε
    # --------------------------------------------------------
    X = np.column_stack([lai_vals, co2])
    X = sm.add_constant(X)
    model = sm.OLS(pur_vals, X).fit()
    beta_lai = model.params[1]
    beta_co2 = model.params[2]
    r2 = model.rsquared

    # --------------------------------------------------------
    # (4) Standardized β coefficients
    # Based on z-scored variables for comparability
    # --------------------------------------------------------
    pur_z = zscore(pur_vals)
    lai_z = zscore(lai_vals)
    co2_z = zscore(co2)
    Xz = sm.add_constant(np.column_stack([lai_z, co2_z]))
    model_z = sm.OLS(pur_z, Xz).fit()
    std_beta_lai = model_z.params[1]
    std_beta_co2 = model_z.params[2]

    # Store all metrics
    results.append([
        city_id, r_corr, p_corr, r_pcorr, p_pcorr,
        beta_lai, beta_co2, r2,
        std_beta_lai, std_beta_co2
    ])

# ============================================================
# 4. Export aggregated results
# ============================================================
df_out = pd.DataFrame(results, columns=[
    "CityID",
    "Pearson_r", "Pearson_p",
    "Partial_r", "Partial_p",
    "Beta_LAI", "Beta_CO2", "R2",
    "Std_Beta_LAI", "Std_Beta_CO2"
])

out_file = r"G:\0023\CO2\partial_regression_results_with_std.xlsx"
df_out.to_excel(out_file, index=False)

print(f"Analysis completed successfully. Results saved to: {out_file}")
