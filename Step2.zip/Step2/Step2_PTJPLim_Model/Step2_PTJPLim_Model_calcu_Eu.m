%This script calculates monthly urban evaporation (Eu) using the PT-JPLim model  
%for global land areas (0.1° resolution) over 2000–2021.

clear
clc
start1 = [1 1 217]; 
count1 = [3600 1800 264]; 
start = [217 1 1]; 
count = [264 1800 3600]; 

fprintf('Reading input data...\n');
P0 = ncread('P_mon2023.nc', 'P', start, count);
P = P0 ./ 30.42;  % Convert monthly precipitation to daily values
LAI=ncread('H:\ServerERA\LAI_20002023.nc','ET');
landcover(:,:,:)=ncread('landcover2023.nc','landcover',start,count);
fu_2d=ncread('fu.nc','fu');  % Read 2D urban fraction data (3601x1801)
fu_2d = fu_2d(1:3600, 1:1800);  % Adjust size to match other data dimensions

% Check and display dimensions for debugging
fprintf('P dimensions: %s\n', mat2str(size(P)));
fprintf('fu_2d dimensions: %s\n', mat2str(size(fu_2d)));

% Set block processing parameters for memory efficiency
block_size = 12;  % Process 12 months at a time
num_blocks = ceil(264/block_size);

% Pre-allocate result array
Eu = zeros(264, 1800, 3600, 'single');

fprintf('Starting block-wise calculation...\n');
for block = 1:num_blocks
    fprintf('Processing block %d of %d...\n', block, num_blocks);
    
    % Calculate current block index range
    start_idx = (block-1)*block_size + 1;
    end_idx = min(block*block_size, 264);
    current_size = end_idx - start_idx + 1;
    
    % Replicate fu data to ensure dimension compatibility
    fu_block = repmat(reshape(fu_2d, [1 1800 3600]), [current_size 1 1]);  % Adjust dimension order and replicate
    
    % Process land cover and fER0 parameters
    fER0_lookup = containers.Map('KeyType', 'double', 'ValueType', 'double');
    fER0_lookup(10) = 0.092;  
    fER0_lookup(20) = 0.256;  
    fER0_lookup(30) = 0.01;   
    fER0_lookup(40) = 0.256; 
    fER0_lookup(70) = 0.01;   
    fER0_lookup(90) = 0.01; 
    fER0_lookup(100) = 0.00;
    fER0_lookup(200) = 0.256; 
    
    % Calculate fER0 for current block
    fER0_block = zeros(current_size, 1800, 3600, 'single');
    landcover_block = landcover(start_idx:end_idx,:,:);
    unique_landcover = unique(landcover_block);
    for lc = unique_landcover(:)'
        if fER0_lookup.isKey(lc)
            fER0_block(landcover_block == lc) = fER0_lookup(lc);
        else
            fER0_block(landcover_block == lc) = 0.01;  % Default value
        end
    end
    
    % Calculate evaporation ratio (fER)
    fER_block = fu_block .* fER0_block;
    clear fER0_block
    
    % Calculate wetting threshold (Pwet)
    Pwet_block = -log(1-(fER_block./fu_block)) .* (0.014./fER_block);
    Pwet_block(isnan(Pwet_block) | isinf(Pwet_block)) = 0;
    
    % Extract precipitation data for current block
    P_block = P(start_idx:end_idx,:,:);
    
    % Check dimension compatibility
    fprintf('Block %d - P_block dimensions: %s, Pwet_block dimensions: %s\n', ...
        block, mat2str(size(P_block)), mat2str(size(Pwet_block)));
    
    % Calculate urban evaporation (Eu)
    mask_block = P_block < Pwet_block;
    Eu_block = zeros(size(P_block), 'single');
    % When precipitation is less than wetting threshold
    Eu_block(mask_block) = fu_block(mask_block) .* P_block(mask_block) .* 30.42;
    % When precipitation exceeds wetting threshold
    Eu_block(~mask_block) = (fu_block(~mask_block) .* Pwet_block(~mask_block) + ...
        fER_block(~mask_block) .* (P_block(~mask_block) - Pwet_block(~mask_block))) .* 30.42;
    
    % Apply urban area filter (only keep areas with landcover = 200)
    Eu_block(landcover_block ~= 200) = 0;
    Eu_block(isnan(Eu_block)) = 0;
    
    % Store current block results
    Eu(start_idx:end_idx,:,:) = Eu_block;
    
    % Clear memory for large temporary variables
    clear fu_block fER_block Pwet_block P_block mask_block Eu_block landcover_block
end

fprintf('Calculation completed, preparing to write output file...\n');

% Create NetCDF file and write data
longitude = 0:0.1:359.9;
latitude = -90:0.1:89.9;
time = 1:1:264;

%%% Create NetCDF file
ncid = netcdf.create('Eu_mon2025.nc','CLOBBER'); 
dimid_lon = netcdf.defDim(ncid,'lon',3600);
dimid_lat = netcdf.defDim(ncid,'lat',1800); 
dimid_tim = netcdf.defDim(ncid,'time',264);
fprintf('Dimensions created successfully\n');

%%% Create variables and attributes
% Longitude variable
varid_lon = netcdf.defVar(ncid,'lon','float',dimid_lon);
netcdf.putAtt(ncid,varid_lon,'long_name','Longitude');
netcdf.putAtt(ncid,varid_lon,'units','degrees_east');
% Latitude variable
varid_lat = netcdf.defVar(ncid,'lat','float',dimid_lat);
netcdf.putAtt(ncid,varid_lat,'long_name','Latitude');
netcdf.putAtt(ncid,varid_lat,'units','degrees_north');
% Time variable
varid_tim = netcdf.defVar(ncid,'time','float',dimid_tim);
netcdf.putAtt(ncid,varid_tim,'long_name','Time');
netcdf.putAtt(ncid,varid_tim,'units','since 198201');
% Main variable
varid_Eu = netcdf.defVar(ncid,'Eu','double',[dimid_tim,dimid_lat,dimid_lon]);
netcdf.putAtt(ncid,varid_Eu,'long_name','Urban Evaporation');
netcdf.putAtt(ncid,varid_Eu,'units','mm/month');
netcdf.putAtt(ncid,varid_Eu,'missing_value',32766);
netcdf.endDef(ncid);
fprintf('Variables defined successfully\n');

%% Write data to NetCDF file
fprintf('Starting data write...\n');
netcdf.putVar(ncid,varid_tim,time);
netcdf.putVar(ncid,varid_lat,latitude);
netcdf.putVar(ncid,varid_lon,longitude);
netcdf.putVar(ncid,varid_Eu,Eu); 
netcdf.close(ncid);

fprintf('Data write completed\n');
fprintf('Program execution finished\n');

%% Generate spatial distribution plot for Eu
fprintf('Generating spatial distribution plot for Eu...\n');
Eu_mean = squeeze(mean(Eu, 1));  % Calculate temporal mean
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, Eu_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Urban Evaporation (Eu)');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\Eu_distribution.png', '-dpng', '-r300');
clear Eu_mean