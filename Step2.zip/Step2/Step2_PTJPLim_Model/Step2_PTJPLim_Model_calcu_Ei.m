%This script calculates monthly interception evaporation (Ei) using the PT-JPLim model  
%for global land areas (0.1° resolution) over 2000–2021.

clear
clc

% Start timing for performance monitoring
total_start_time = tic;
fprintf('\n========== Starting Ei (Interception Evaporation) Calculation ==========\n');
fprintf('Start time: %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));

% Define data reading parameters for NetCDF files
start1 = [1 1 217]; 
count1 = [3600 1800 264]; 
start = [217 1 1]; 
count = [264 1800 3600]; 

fprintf('========== Step 1: Reading Input Data ==========\n');
step_time = tic;

% Read and process precipitation data
fprintf('Reading precipitation data...\n');
P0 = ncread('P_mon2023.nc', 'P', start, count);
P = P0 ./ 30.42;  % Convert monthly precipitation to daily values
clear P0

% Read LAI (Leaf Area Index) and land cover data
fprintf('Reading LAI and land cover data...\n');
LAI=ncread('H:\ERA\LAI_20002023.nc','ET');
landcover = ncread('landcover2023.nc', 'landcover', start, count);

fprintf('Input data reading completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 2: Calculating fv and sv Parameters ==========\n');
step_time = tic;

% Calculate vegetation fraction (fv) using exponential relationship with LAI
fv = 1 - exp(-LAI./5);

% Create lookup table for S parameter based on land cover types
S_lookup = containers.Map('KeyType', 'double', 'ValueType', 'double');
S_lookup(10) = 0.01;   
S_lookup(20) = 0.198;
S_lookup(30) = 0.227;
S_lookup(40) = 0.198;
S_lookup(70) = 0.014;
S_lookup(90) = 0.014;
S_lookup(100) = 0.00;
S_lookup(200) = 0.198;

% Vectorized calculation of S parameter
S = zeros(size(landcover), 'single');
unique_landcover = unique(landcover);
for lc = unique_landcover(:)'
    if S_lookup.isKey(lc)
        S(landcover == lc) = S_lookup(lc);
    else
        S(landcover == lc) = 0.01;  % Default value for unknown land cover types
    end
end

% Calculate storage capacity parameter (sv)
sv = S .* LAI;
clear S

fprintf('fv and sv calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 3: Calculating fER Parameter ==========\n');
step_time = tic;

% Create lookup table for fER0 parameter based on land cover types
fER0_lookup = containers.Map('KeyType', 'double', 'ValueType', 'double');
fER0_lookup(10) = 0.092;  
fER0_lookup(20) = 0.256;  
fER0_lookup(30) = 0.01;  
fER0_lookup(40) = 0.256; 
fER0_lookup(70) = 0.01;  
fER0_lookup(90) = 0.01;   
fER0_lookup(100) = 0.00; 
fER0_lookup(200) = 0.256;
% Vectorized calculation of fER0 parameter
fER0 = zeros(size(landcover), 'single');
for lc = unique_landcover(:)'
    if fER0_lookup.isKey(lc)
        fER0(landcover == lc) = fER0_lookup(lc);
    else
        fER0(landcover == lc) = 0.01;  % Default value for unknown land cover types
    end
end

% Calculate evaporation ratio parameter (fER)
fER = fv .* fER0;
clear fER0 landcover

fprintf('fER calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 4: Calculating Pwet Threshold ==========\n');
step_time = tic;

% Calculate wetting threshold (Pwet) using logarithmic relationship
Pwet = -log(1 - (fER ./ fv)) .* (sv ./ fER);
% Handle potential invalid values (NaN or Inf)
Pwet(isnan(Pwet) | isinf(Pwet)) = 0;

clear sv
fprintf('Pwet calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 5: Calculating Interception Evaporation (Ei) ==========\n');
step_time = tic;

% Calculate interception evaporation based on precipitation threshold
mask = P < Pwet;
Ei = zeros(size(P), 'single');
% When precipitation is less than wetting threshold
Ei(mask) = fv(mask) .* P(mask) .* 30.42;
% When precipitation exceeds wetting threshold
Ei(~mask) = (fv(~mask) .* Pwet(~mask) + fER(~mask) .* (P(~mask) - Pwet(~mask))) .* 30.42;

clear P Pwet fv fER mask
fprintf('Ei calculation completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 6: Computing Spatial Averages ==========\n');
step_time = tic;

% Calculate temporal mean for each grid cell
Zrsum = zeros(264, 1);
for i = 1:264
    slice = Ei(i,:,:);
    valid_data = slice(~isnan(slice));
    if ~isempty(valid_data)
        Zrsum(i) = mean(valid_data);
    end
end

fprintf('Spatial averaging completed in %.2f seconds\n\n', toc(step_time));

fprintf('========== Step 7: Creating NetCDF Output File ==========\n');
step_time = tic;

% Prepare coordinate data for NetCDF file
longitude = 0:0.1:359.9;
latitude = -90:0.1:89.9;
time = 1:1:264;

% Create NetCDF file
ncid = netcdf.create('Ei_mon2025.nc', 'CLOBBER');

% Define dimensions
dimid_lon = netcdf.defDim(ncid, 'lon', 3600);
dimid_lat = netcdf.defDim(ncid, 'lat', 1800);
dimid_tim = netcdf.defDim(ncid, 'time', 264);

% Define variables with metadata
varid_lon = netcdf.defVar(ncid, 'lon', 'float', dimid_lon);
netcdf.putAtt(ncid, varid_lon, 'long_name', 'Longitude');
netcdf.putAtt(ncid, varid_lon, 'units', 'degrees_east');

varid_lat = netcdf.defVar(ncid, 'lat', 'float', dimid_lat);
netcdf.putAtt(ncid, varid_lat, 'long_name', 'Latitude');
netcdf.putAtt(ncid, varid_lat, 'units', 'degrees_north');

varid_tim = netcdf.defVar(ncid, 'time', 'float', dimid_tim);
netcdf.putAtt(ncid, varid_tim, 'long_name', 'Time');
netcdf.putAtt(ncid, varid_tim, 'units', 'since 198201');

varid_Ei = netcdf.defVar(ncid, 'Ei', 'double', [dimid_tim, dimid_lat, dimid_lon]);
netcdf.putAtt(ncid, varid_Ei, 'long_name', 'Interception Evaporation');
netcdf.putAtt(ncid, varid_Ei, 'units', 'mm/month');
netcdf.putAtt(ncid, varid_Ei, 'missing_value', 32766);
netcdf.endDef(ncid);

% Write data to NetCDF file
fprintf('Writing data to NetCDF file...\n');
netcdf.putVar(ncid, varid_tim, time);
netcdf.putVar(ncid, varid_lat, latitude);
netcdf.putVar(ncid, varid_lon, longitude);
netcdf.putVar(ncid, varid_Ei, Ei);
netcdf.close(ncid);

fprintf('NetCDF file creation completed in %.2f seconds\n\n', toc(step_time));

% Output total execution time
total_time = toc(total_start_time);
fprintf('\n========== Program Execution Completed ==========\n');
fprintf('End time: %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));
fprintf('Total execution time: %.2f seconds (%.2f minutes)\n', total_time, total_time/60);


%% Generate spatial distribution plot for Ei
fprintf('Generating spatial distribution plot for Ei...\n');
Ei_mean = squeeze(mean(Ei, 1).*12);  % Convert to annual values
figure('Position', [100 100 800 600]);
imagesc(longitude, latitude, Ei_mean);
colormap(jet(256));
colorbar;
title('Spatial Distribution of Interception Evaporation (Ei)');
xlabel('Longitude');
ylabel('Latitude');
set(gcf, 'Color', 'white');
print('H:\ServerERA\ET2024_Simulation\Ei_distribution.png', '-dpng', '-r300');
clear Ei_mean
